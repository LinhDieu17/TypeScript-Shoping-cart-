"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const product_repository_1 = require("./product-repository");
const cart_1 = require("./cart");
const validate_1 = require("./libs/validate");
//ta nên định nghĩa id (list-product,mnotification,... ) thành các hằng số để sau này có thay đổi gì cũng dễ dàng hơn 
var MElement;
(function (MElement) {
    MElement.ELM_LIST_PRODUCT = "#list-product";
    MElement.ELM_NOTIFICATION = "#mnotification";
    MElement.ELM_CART_BODY = "#my-cart-body";
    MElement.ELM_CART_FOOTER = "#my-cart-footer";
})(MElement || (MElement = {}));
var MNotification;
(function (MNotification) {
    MNotification.NOTI_READY_TO_BUY = "Ready to by product";
    MNotification.NOTI_GREATER_THAN_ONE = "Quantity must equal or greater than 1";
    MNotification.NOTI_ACT_ADD = "Add sucessfull !";
    MNotification.NOTI_ACT_UPDATE = "Updated sucessfull !";
    MNotification.NOTI_ACT_DELETE = "Deleted sucessfull !";
})(MNotification || (MNotification = {}));
//tạo ra repository để lấy các sản phẩm 
let productRepository = new product_repository_1.ProductRepository();
//tạo ra 1 đối tượng để thêm các product vào khi người dùng chọn mua sp
let cartObj = new cart_1.Cart();
//tạo ra 1 mảng hứng các kq trả về khi getItems()
let products = productRepository.getItems();
function showListProduct() {
    // $("#list-product").html(productRepository.showItemsInHTML());
    $(MElement.ELM_LIST_PRODUCT).html(productRepository.showItemsInHTML());
}
//các thông báo hiển thị ra có nội dung khác nhau 
function showNotification(str) {
    $(MElement.ELM_NOTIFICATION).html(str);
}
//hiển thị giỏ hàng 
function showCart() {
    $(MElement.ELM_CART_BODY).html(cartObj.showCartBodyInHTML());
    $(MElement.ELM_CART_FOOTER).html(cartObj.showCartFooterInHTML());
}
//addProduct: thêm sp vào giỏ hàng 
function addProduct(id, quantity) {
    //neu quantity hop le ta moi di add product 
    if (validate_1.Validate.checkQuantity(quantity)) {
        let product = productRepository.getItemByID(id);
        cartObj.addProduct(product, quantity);
        showCart();
        showNotification(MNotification.NOTI_ACT_ADD);
    }
    else {
        showNotification(MNotification.NOTI_GREATER_THAN_ONE);
    }
}
//update product: update sản phẩm 
function updateProduct(id, quantity) {
    //neu quantity hop le ta moi di add product 
    if (validate_1.Validate.checkQuantity(quantity)) {
        //add product
        let product = productRepository.getItemByID(id);
        cartObj.updateProduct(product, quantity);
        showCart();
        showNotification(MNotification.NOTI_ACT_UPDATE);
    }
    else {
        showNotification(MNotification.NOTI_GREATER_THAN_ONE);
    }
}
//delete product: xoá sản phẩm 
function deleteProduct(id) {
    let product = productRepository.getItemByID(id);
    cartObj.removeProduct(product);
    showCart();
    showNotification(MNotification.NOTI_ACT_DELETE);
}
//khi vừa vào trang, những phương thức sau được gọi (bắt sự kiện)
$(document).ready(function () {
    // khi vừa vào trang:
    //hiển thị danh sách các sản phẩm 
    showListProduct();
    //Giỏ hàng rỗng: my-cart-body, my-cart-footer 
    showCart();
    //Update thông báo: 
    showNotification(MNotification.NOTI_READY_TO_BUY);
    //khi thẻ a được click vào, cần lấy được id, số lượng sp mà người dùng muốn mua 
    $("a.price").click(function () {
        //lấy id của sản phẩm
        let id = $(this).data("product"); //this ở đây chính là thẻ a 
        //lấy quantity 
        let quantity = parseInt($("input[name='quantity-product-" + id + "']").val()); //parseInt() ＝> chuyến số bên trong sang số tự nhiên (>0)
        //neu quantity hop le ta moi di add product 
        addProduct(id, quantity);
        // 		return false;
    });
    // update product: cập nhật lại thông tin của 1 sảm phẩm trong giỏ hàng khi thêm, bớt số lượng
    $(document).on("click", "a.update-cart-item", function () {
        let id = $(this).data("product"); //this ở đây chính là thẻ a
        let quantity = parseInt($("input[name='cart-item-quantity-" + id + "']").val());
        updateProduct(id, quantity);
        // 		return false;
    });
    //delete product khỏi cartItem 
    $(document).on("click", "a.delete-cart-item", function () {
        let id = $(this).data("product"); //this ở đây chính là thẻ a
        deleteProduct(id);
        // 		return false;
    });
});
