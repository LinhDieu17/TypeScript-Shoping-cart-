// cart dùng để biểu diễn danh sách các item mà người dùng muốn mua 
import { CartItem } from "./cart-item";
import { Product } from "./product";
import { Helpers } from "./libs/helpers";



export class Cart {
    private cartItems: CartItem[] = [];
    private totalQuantity: number = 0;
    private totalPrice: number = 0; 

    public addProduct (product: Product, quantity: number = 1) : void {
        //position là vị trí của sp cần cập nhật
        let position : number = this.getProductPosition (product);
        if(position> -1) {
            //đã tồn tại thì cập nhật lại số lượng
            this.cartItems[position].quantity  += quantity; 
        }else {
            //chưa tồn tại, thêmn mới như bt 
            //đối tượng cartItem dùng để chứa các product được thêm vào 
        this.cartItems[this.cartItems.length] = new CartItem(product, quantity); // sử dụng phương thúc push thay cáchn viết này cũng được 
        }
        //cứ mỗi lần addProduct được gọi ta cập nhật lại totalQuantity và totalPrice 
        this.totalQuantity += quantity;
        this.totalPrice += product.price * quantity;
    }

    //phương thức kiểm tra xem sp được chọn đã nằm trong giở hàng hay chưa, nếu đã nằm trong giỏ hàng thì return lại chỉ số của sp đó và cập nhật lại quantity cho nó, chưa thì thêm mới vào như bt 
    private getProductPosition (product: Product) : number {
        let total: number = this.cartItems.length;
        for(let i: number = 0; i < total; i ++){
            //duyệt qua tất cả các sp trong giỏ hàng, nếu như sp nào có id == id mà người dùng click vào mua thì chứng tỏ sp này đã tồn tại 
            if(this.cartItems[i].product.id == product.id) 
                return i; //trả về i - vị trí (chỉ số 0/1/2/3/....) của sp cần cập nhật lại  
        }
        return -1;
    }

    public updateProduct (product: Product, quantity: number = 1) : void {
        //đầu tiên ta cũng tìm trong cart item sp đó có chỉ số là bao nhiêu
        let position : number = this.getProductPosition (product);
        //nếu chỉ số đó > -1 (tức là có sp đó ) thì cập nhật lại quantity cho nó 
        if(position> -1) {
            //name  quan price total 
            //a      5    1     5
            //b      4    2     8
            //c      *3   3    *9        => totalQ: 12   ,  totalP : 22

            //a      5    1     5
            //b      4    2     8
            //c      *1   3    *6        => totalQ: 11 = 12 - 3 + 2    ,  totalP : 16  = 22 - 3*3 + 3*1 = 22 - 3*(3-1)


            //Sau khi cập nhật lại số lượng sp cũng cân phải cập nhật lại totalQuantity, totalPrice
            this.totalQuantity = this.totalQuantity - this.cartItems[position].quantity + quantity;
            this.totalPrice  = this.totalPrice - product.price*(this.cartItems[position].quantity -quantity);

            this.cartItems[position].quantity = quantity; //số sp hiện tại
        }
    }

    public removeProduct (product: Product) : void {
        let position : number = this.getProductPosition (product);
        if(position> -1) {
            this.totalQuantity = this.totalQuantity - this.cartItems[position].quantity;
            this.totalPrice  = this.totalPrice - product.price*this.cartItems[position].quantity;

            this.cartItems.splice(position, 1);         //xoá 1 phần tử ra khỏi array 
        }

    }

    //kiểm tra giỏ hàng có rỗng hay không
    public isEmpty() : boolean {
        return (this.cartItems.length == 0);
    }

    //cách viết dứoi đây chưa được tối ưu 
    /* 
    //tính tổng số lượng 
    public getTotalQuantity() : number {
        //duyệt qua mỗi phẩn tử của cartItems => lấy tổng số lượng của nó 
        let total : number = 0;
        this.cartItems.forEach((cartItem: CartItem) => {
            total += cartItem.quantity;
        });
        return total;
    }
    */

    /*
    //tính tổng số tiền 
    public getTotalPrice() : number {
        let total : number = 0;
        this.cartItems.forEach((cartItem: CartItem) => {
            total += cartItem.quantity * cartItem.product.price;
        });
        return total;
    }
    */

    public showCartBodyInHTML() : string {
        let xhtmlResult : string = " ";
        //nếu giỏ hàng khác rỗng 
        if(!this.isEmpty()) {
            //duyệt qua danh sách các sản phẩm
            let total : number = this.cartItems.length;
            for(let i: number = 0; i < total; i++) {
                let cartItemCurrent : CartItem = this.cartItems[i];
                xhtmlResult += cartItemCurrent.showItemInHTML(i + 1);
            }
        }
        return xhtmlResult;
    }

    // hiển thị phần thống kê của giỏ hàng, có bao nhiêu sp, tống số tiền
    public showCartFooterInHTML(): string {
        //khi mới vào trang ta luôn nhận được tb là giỏ hàng đang rỗng 
        let xhtmlResult : string = `<tr><th colspan = "6">Empty product in your cart</th></th>`;
        if(!this.isEmpty()) {
            xhtmlResult = `<tr>
                <td colspan = "4">There are <b>${ this.totalQuantity }</b> items in your shopping cart.</td>
                <td colspan = "2" class="total-price text-left">${  Helpers.toCurrency(this.totalPrice, "USD", "right")  }</td>
            <tr>`;
        }
        return xhtmlResult; 

    }
}