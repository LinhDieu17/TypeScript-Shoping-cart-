//nhận vào và hiển thị các loại ký kiệu của đơn vị tiền tệ, vị trí hiển thị
export class Helpers {
    // $ 20 - 20 $ - 20 VND - 20 USD 
    public static toCurrency(value: number, currencyUnit: string, position: string = "left") : string {
        if(position == "left") {
            return currencyUnit + " " + value;
        } else if (position == "right") {
            return value + " " + currencyUnit;
        }
    }
}