//tập tin này kiểm tra xem các dữ liệu có hợp lệ hay ko 
    // giá trị quantity có hợp hệ hay không
export class Validate {
    public static isNumber(value: any) : boolean {
        return !isNaN(parseFloat(value)) && isFinite(value);
    }

    //check xem quantity co hop le hay ko
    public static checkQuantity(value: any): boolean {
        if(value < 1 || Validate.isNumber(value) == false) {
            return false;
        } else {
            return true;
        }
    }
}