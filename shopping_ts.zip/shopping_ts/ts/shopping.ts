import { ProductRepository } from "./product-repository";
import { Product } from "./product"
import { Cart } from "./cart"
import { Validate } from "./libs/validate";

//ta nên định nghĩa id (list-product,mnotification,... ) thành các hằng số để sau này có thay đổi gì cũng dễ dàng hơn 
namespace MElement {
   export const ELM_LIST_PRODUCT : string = "#list-product";
   export const ELM_NOTIFICATION : string = "#mnotification";
   export const ELM_CART_BODY : string = "#my-cart-body";
   export const ELM_CART_FOOTER : string = "#my-cart-footer";
   
}

namespace MNotification {
    export const NOTI_READY_TO_BUY : string = "Ready to by product";
    export const NOTI_GREATER_THAN_ONE : string = "Quantity must equal or greater than 1";
    export const NOTI_ACT_ADD : string = "Add sucessfull !"; 
    export const NOTI_ACT_UPDATE : string = "Updated sucessfull !";
    export const NOTI_ACT_DELETE : string = "Deleted sucessfull !";
} 

//tạo ra repository để lấy các sản phẩm 
let productRepository =  new ProductRepository();
//tạo ra 1 đối tượng để thêm các product vào khi người dùng chọn mua sp
let cartObj = new Cart();
//tạo ra 1 mảng hứng các kq trả về khi getItems()
let products : Product[] = productRepository.getItems();

function showListProduct() : void {
    // $("#list-product").html(productRepository.showItemsInHTML());
    $(MElement.ELM_LIST_PRODUCT).html(productRepository.showItemsInHTML());
}

//các thông báo hiển thị ra có nội dung khác nhau 
function showNotification(str: string) : void {
    $(MElement.ELM_NOTIFICATION).html(str);
}

//hiển thị giỏ hàng 
function showCart() : void {
    $(MElement.ELM_CART_BODY).html(cartObj.showCartBodyInHTML());
    $(MElement.ELM_CART_FOOTER).html(cartObj.showCartFooterInHTML());
}

//addProduct: thêm sp vào giỏ hàng 
function addProduct(id: number, quantity: number) {
    //neu quantity hop le ta moi di add product 
    if(Validate.checkQuantity(quantity)) {
        let product : Product = productRepository.getItemByID(id);
        cartObj.addProduct(product, quantity); 
        showCart();
        showNotification(MNotification.NOTI_ACT_ADD);
    } else {
        showNotification(MNotification.NOTI_GREATER_THAN_ONE);
    }
} 

//update product: update sản phẩm 
function updateProduct(id: number, quantity: number) {
    //neu quantity hop le ta moi di add product 
    if(Validate.checkQuantity(quantity)) {
        //add product
        let product : Product = productRepository.getItemByID(id);
        cartObj.updateProduct(product, quantity); 
        showCart();
        showNotification(MNotification.NOTI_ACT_UPDATE);
    } else {
        showNotification(MNotification.NOTI_GREATER_THAN_ONE);
    }
}

//delete product: xoá sản phẩm 
function deleteProduct(id: number) {
    let product : Product = productRepository.getItemByID(id);
    cartObj.removeProduct(product); 
    showCart();
    showNotification(MNotification.NOTI_ACT_DELETE);

}

//khi vừa vào trang, những phương thức sau được gọi (bắt sự kiện)
$(document).ready(function(){
// khi vừa vào trang:
    //hiển thị danh sách các sản phẩm 
    showListProduct();
    //Giỏ hàng rỗng: my-cart-body, my-cart-footer 
    showCart();
    //Update thông báo: 
    showNotification(MNotification.NOTI_READY_TO_BUY);
//khi thẻ a được click vào, cần lấy được id, số lượng sp mà người dùng muốn mua 
    $("a.price").click(function(){
        //lấy id của sản phẩm
        let id : number = $(this).data("product");   //this ở đây chính là thẻ a 
        //lấy quantity 
        let quantity : number = parseInt($("input[name='quantity-product-" + id + "']").val()); //parseInt() ＝> chuyến số bên trong sang số tự nhiên (>0)
        //neu quantity hop le ta moi di add product 
        addProduct(id, quantity);
        // 		return false;
    });
// update product: cập nhật lại thông tin của 1 sảm phẩm trong giỏ hàng khi thêm, bớt số lượng
    $(document).on("click", "a.update-cart-item", function(){
        let id : number = $(this).data("product");   //this ở đây chính là thẻ a
        let quantity : number = parseInt($("input[name='cart-item-quantity-" + id + "']").val());
        updateProduct(id, quantity);
        // 		return false;
    });

//delete product khỏi cartItem 
    $(document).on("click", "a.delete-cart-item", function(){
        let id : number = $(this).data("product");   //this ở đây chính là thẻ a
        deleteProduct(id);
        // 		return false;
    });

});